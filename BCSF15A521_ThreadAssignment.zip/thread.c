#include<stdio.h>
#include<stdlib.h>
#include<pthread.h>

int totalSum = 0;
void calculation(int nmbr)
{
	int j = nmbr;
	int localSum = 0;
 
	for (j=nmbr ; j<nmbr+100 ; j++)
	{
		localSum = localSum + j;
	}
	totalSum = totalSum + localSum;
}

void main(int argc, char const *argv[])
{
	/* code */
	pthread_t t1;

	int i=0;
	int start = 0;
	
	// it'll run for 10 times and for every iteration it'll calculate next 100 numbers and add 		to totalSum ...
	for (i=0 ; i<10 ; i++)
	{
		pthread_create(&t1,NULL,calculation,start);
		pthread_join(t1,NULL);
		start = start + 100;
	}
	

	printf("Total Sum : %d\n", totalSum);
}
